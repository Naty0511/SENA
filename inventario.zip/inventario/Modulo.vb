﻿Module Modulo
    Public registro As Integer
    Public codigo() As String
    Public descripcion() As String
    Public precio() As Decimal
    Public existencia() As Integer
    Public categoria() As String

    Public Function getCostoTotal(ByRef pos As Integer, ByVal precio As Decimal, ByVal existencia As Integer) As Decimal
        Dim total = 0

        total = existencia * precio 
        Return total
    End Function

    Public Function getPorcentajeUtilidad(ByVal categoria As String) As Decimal
        Dim porcentaje As Decimal

        If (categoria = 1) Then
            porcentaje = 0
        ElseIf (categoria = 2) Then
            porcentaje = 0
        ElseIf (categoria = 3) Then
            porcentaje = 0
        ElseIf (categoria = 4) Then
            porcentaje = 0
        ElseIf (categoria = 5) Then
            porcentaje = 0
        End If

        Return porcentaje

    End Function

    Public Function getCostoPorcentaje(ByRef pos As Integer, ByVal precio As Decimal, ByVal existencia As Integer, ByVal categoria As String) As Decimal
        Return getCostoTotal(pos, precio, existencia) + getPorcentajeUtilidad(categoria)
    End Function

    Public Function getPrecioVenta(ByRef pos As Integer, ByVal precio As Decimal, ByVal existencia As Integer, ByVal categoria As String) As Decimal
        Return getCostoPorcentaje(pos, precio, existencia, categoria) + getCostoTotal(pos, precio, existencia)
    End Function

End Module
