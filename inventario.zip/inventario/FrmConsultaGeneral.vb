﻿Public Class FrmConsultaGeneral

    Private Sub FrmConsultaGeneral_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub FrmConsultaGeneral_Activated(sender As Object, e As EventArgs) Handles Me.Activated
        grdDatos.Rows.Clear()
        Dim ganancia As Decimal
        Dim total As Decimal

        For pos = 0 To registro - 1
            grdDatos.Rows.Add(codigo(pos), descripcion(pos), precio(pos), existencia(pos), categoria(pos),
                getCostoTotal(pos, precio(pos), existencia(pos)), getCostoPorcentaje(pos, precio(pos), existencia(pos), categoria(pos)),
                getPrecioVenta(pos, precio(pos), existencia(pos), categoria(pos)))

            ganancia = ganancia + getCostoPorcentaje(pos, precio(pos), existencia(pos), categoria(pos))
            total = total + getPrecioVenta(pos, precio(pos), existencia(pos), categoria(pos))

        Next

        txtGanancia.Text = ganancia
        txtTotal.Text = total

    End Sub

End Class