﻿Public Class FrmConsultaCriterio
    Private Sub FrmConsultaCriterio_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cmbCategoria.Items.Add("Verduras")
        cmbCategoria.Items.Add("Bebidas")
        cmbCategoria.Items.Add("Cuidado Personal")
        cmbCategoria.Items.Add("Lacteos")
        cmbCategoria.Items.Add("Carnes Frias")
    End Sub

    Private Sub FrmConsultaCriterio_Activated(sender As Object, e As EventArgs) Handles Me.Activated
        grdDatos.Rows.Clear()
        Dim ganancia As Decimal
        Dim total As Decimal

        For pos = 0 To registro - 1
            grdDatos.Rows.Add(codigo(pos), descripcion(pos), precio(pos), existencia(pos), categoria(pos),
                getCostoTotal(pos, precio(pos), existencia(pos)), getCostoPorcentaje(pos, precio(pos), existencia(pos), categoria(pos)),
                getPrecioVenta(pos, precio(pos), existencia(pos), categoria(pos)))

            ganancia = ganancia + getCostoPorcentaje(pos, precio(pos), existencia(pos), categoria(pos))
            total = total + getPrecioVenta(pos, precio(pos), existencia(pos), categoria(pos))

        Next

        txtGanancia.Text = ganancia
        txtTotal.Text = total
    End Sub
    Private Sub cmbCategoria_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbCategoria.SelectedIndexChanged
        grdDatos.Rows.Clear()
        Dim ganancia As Decimal
        Dim total As Decimal
        Dim cate As String

        cate = cmbCategoria.SelectedIndex

        For pos = 0 To registro - 1

            If (categoria(pos) = cate) Then


                grdDatos.Rows.Add(codigo(pos), descripcion(pos), precio(pos), existencia(pos), categoria(pos),
                getCostoTotal(pos, precio(pos), existencia(pos)), getCostoPorcentaje(pos, precio(pos), existencia(pos), categoria(pos)),
                getPrecioVenta(pos, precio(pos), existencia(pos), categoria(pos)))

                ganancia = ganancia + getCostoPorcentaje(pos, precio(pos), existencia(pos), categoria(pos))
                total = total + getPrecioVenta(pos, precio(pos), existencia(pos), categoria(pos))
            End If
        Next

        txtGanancia.Text = ganancia
        txtTotal.Text = total
    End Sub


End Class