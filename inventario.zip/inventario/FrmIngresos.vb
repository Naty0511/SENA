﻿Public Class FrmIngresos
    Private Sub FrmIngresos_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cmbCategoria.Items.Add("Verduras")
        cmbCategoria.Items.Add("Bebidas")
        cmbCategoria.Items.Add("Cuidado Personal")
        cmbCategoria.Items.Add("Lacteos")
        cmbCategoria.Items.Add("Carnes Frias")
    End Sub

    Private Sub limpiar()
        txtCodigo.Clear()
        txtDescripcion.Clear()
        txtExistencia.Clear()
        txtPrecio.Clear()
    End Sub

    Private Sub cmdGuardar_Click(sender As Object, e As EventArgs) Handles cmdGuardar.Click
        ReDim Preserve codigo(registro + 1)
        ReDim Preserve descripcion(registro + 1)
        ReDim Preserve existencia(registro + 1)
        ReDim Preserve precio(registro + 1)
        ReDim Preserve categoria(registro + 1)

        Try

            codigo(registro) = txtCodigo.Text
            descripcion(registro) = txtDescripcion.Text
            existencia(registro) = txtExistencia.Text
            precio(registro) = txtPrecio.Text
            categoria(registro) = cmbCategoria.SelectedIndex


            MsgBox("Datos Guardados")
            registro = registro + 1
            limpiar()

        Catch ex As Exception

            MsgBox("Ingrese bien los datos")
            limpiar()

        End Try
    End Sub
End Class