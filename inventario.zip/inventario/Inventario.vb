﻿Public Class Form1
    Private Sub ProductoToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ProductoToolStripMenuItem.Click
        FrmIngresos.Show()
    End Sub

    Private Sub GeneralToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles GeneralToolStripMenuItem.Click
        FrmConsultaGeneral.Show()
    End Sub

    Private Sub CriterioToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CriterioToolStripMenuItem.Click
        FrmConsultaCriterio.Show()
    End Sub
End Class
