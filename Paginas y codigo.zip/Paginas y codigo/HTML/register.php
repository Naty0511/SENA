<?php
require 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Validar campos no vacíos
    if (empty($username) || empty($password)) {
        echo "Todos los campos son obligatorios.";
        exit;
    }

    // Encriptar la contraseña
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    // Insertar el usuario en la base de datos
    $stmt = $conn->prepare("INSERT INTO usuarios (username, password) VALUES (:username, :password)");
    $stmt->bindParam(':username', $username);
    $stmt->bindParam(':password', $hashedPassword);

    try {
        $stmt->execute();
        echo "Registro exitoso. Ahora puedes iniciar sesión.";
    } catch (PDOException $e) {
        if ($e->getCode() == 23000) { // Código para clave duplicada
            echo "El nombre de usuario ya está en uso.";
        } else {
            echo "Error en el registro: " . $e->getMessage();
        }
    }
}
?>
