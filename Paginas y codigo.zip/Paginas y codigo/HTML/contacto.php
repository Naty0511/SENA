<?php
// Verificar si el formulario fue enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recibir y sanitizar los datos del formulario
    $nombre = htmlspecialchars($_POST['txtNombre']);
    $apellido = htmlspecialchars($_POST['txtApellido']);
    $email = filter_var($_POST['txtEmail'], FILTER_SANITIZE_EMAIL);
    $mensaje = htmlspecialchars($_POST['txtMensaje']);

    // Configurar el destinatario del correo (tu dirección de correo)
    $para = "saritavallejo36@gmail.com"; // Cambia esto por tu dirección de correo electrónico
    $asunto = "Mensaje de Contacto de " . $nombre . " " . $apellido;

    // Cuerpo del mensaje
    $contenido = "Nombre: $nombre\n";
    $contenido .= "Apellido: $apellido\n";
    $contenido .= "Email: $email\n";
    $contenido .= "Mensaje:\n$mensaje\n";

    // Cabeceras del correo
    $cabeceras = "From: $email" . "\r\n" .
                 "Reply-To: $email" . "\r\n" .
                 "X-Mailer: PHP/" . phpversion();

    // Enviar el correo
    if (mail($para, $asunto, $contenido, $cabeceras)) {
        echo "Mensaje enviado correctamente";
    } else {
        echo "Hubo un error al enviar el mensaje. Inténtalo de nuevo.";
    }
}
?>
