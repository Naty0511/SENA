using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Facturacion_Berthoonline.Models
{
    public class Factura
    {
        public string numeroFactura { get; set; }
        public int idCliente { get; set; }
        public string numeroPago { get; set; }
        public int IdVendedor { get; set; }
        public DateTime fechaFactura { get; set; }
        public DateTime fechaPedido { get; set; }
        public string numeroPedido { get; set; }
    }
}