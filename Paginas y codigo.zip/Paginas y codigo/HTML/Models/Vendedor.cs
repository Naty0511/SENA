using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Facturacion_Berthoonline.Models
{
    public class Vendedor
    {
        public int idVendedor { get; set; }
        public string cedula { get; set; }
        public string nombreVendedor { get; set; }
        public string apellidoVendedor { get; set; }
        public string direccion { get; set; }
        public string telefono { get; set; }
        public string email { get; set; }
    }
}