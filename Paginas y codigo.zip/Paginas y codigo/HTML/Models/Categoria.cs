using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace facturacion_Berthoonline.Models
{
    public class Categoria
    {
        public int idCategoria { get; set; }
        public string nombreCategoria{ get; set; }
        public string descripcion { get; set; }
   
    }
}