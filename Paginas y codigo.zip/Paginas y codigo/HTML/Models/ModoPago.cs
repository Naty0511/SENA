using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Facturacion_Berthoonline.Models
{
    public class ModoPago
    {
        public int numeroPago { get; set; }
        public string nombre { get; set; }
        public string otroDetalles { get; set; }
       
    }
}