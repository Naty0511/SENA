using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Facturacion_Berthoonline.Models
{
    public class Cliente
    {

        public int idCliente { get; set; }
        public string cedula { get; set; }
        public string nombreCliente { get; set; }
        public string apellidoCliente { get; set; }
        public string direccion { get; set; }
        public string telefono { get; set; }
        public string email { get; set; }

        internal static bool actualizarCliente(Cliente oCliente)
        {
            throw new NotImplementedException();
        }

        internal static bool insertarCliente(Cliente oCliente)
        {
            throw new NotImplementedException();
        }
    }
}