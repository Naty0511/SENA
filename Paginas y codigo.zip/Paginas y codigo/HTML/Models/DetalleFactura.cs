using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Facturacion_Berthoonline.Models
{
    public class DetalleFactura
    {
        public int numeroFactura { get; set; }
        public int idProducto { get; set; }
        public int Cantidad { get; set; }
        public decimal importe{ get; set; }
        public decimal subtotal { get; set; }
        public decimal total{ get; set; }
    }
}