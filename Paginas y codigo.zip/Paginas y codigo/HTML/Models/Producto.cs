using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Facturacion_Berthoonline.Models
{
    public class Producto
    {
        public int idProducto { get; set; }
        public int idCategoria { get; set; }
        public int idProveedor { get; set; }
        public string nombreProducto { get; set; }
        public string descripcion { get; set; }
        public int existencias { get; set; }
        public decimal precioUnitario { get; set; }
        public string email { get; set; }
    }
}