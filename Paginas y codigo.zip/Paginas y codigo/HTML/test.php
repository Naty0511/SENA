<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    echo "Datos recibidos correctamente por POST.";
} else {
    echo "Método no permitido.";
}
?>
