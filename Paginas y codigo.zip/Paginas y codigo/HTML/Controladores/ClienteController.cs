using Facturacion_Berthoonline.Data;
using Facturacion_Berthoonline.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Facturacion_Berthoonline.Controllers
{
    public class ClienteController : ApiController
    {
        // GET api/<controller>
        public List<Cliente> Get()
        {
            return ClienteData.Listar();
        }

        // POST api/<controller>
        public bool Post([FromBody] Cliente oCliente)
        {
            return ClienteData.insertarCliente(oCliente);
        }

        // PUT api/<controller>/5
        public bool Put([FromBody] Cliente oCliente)
        {
            return ClienteData.ActualizarCliente(oCliente);
        }
        // DELETE api/<controller>/5
        public bool Delete(string id)
        {
            return ClienteData.eliminarCliente(id);
        }
    }
}