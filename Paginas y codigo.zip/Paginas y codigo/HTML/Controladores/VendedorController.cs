using Facturacion_Berthoonline.Data;
using Facturacion_Berthoonline.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace  Facturacion_Berthoonline.Controllers
{
    public class VendedorController : ApiController
    {
        // GET api/<controller>
        public List<Vendedor> Get()
        {
            return VendedorData.Listar();
        }

        // POST api/<controller>
        public bool Post([FromBody] Vendedor oVendedor)
        {
            return VendedorData.insertarVendedor(oVendedor);
        }

        // PUT api/<controller>/5
        public bool Put([FromBody] Vendedor oVendedor)
        {
            return VendedorData.ActualizarVendedor(oVendedor);
        }
        // DELETE api/<controller>/5
        public bool Delete(string id)
        {
            return VendedorData.eliminarVendedor(id);
        }
    }
}