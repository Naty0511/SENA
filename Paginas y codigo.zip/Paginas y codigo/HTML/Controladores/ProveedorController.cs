using Facturacion_Berthoonline.Data;
using Facturacion_Berthoonline.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Facturacion_Berthoonline.Controllers
{
    public class ProveedorController : ApiController
    {
        // GET api/<controller>
        public List<Proveedor> Get()
        {
            return ProveedorData.Listar();
        }

        // POST api/<controller>
        public bool Post([FromBody] Proveedor oProveedor)
        {
            return ProveedorData.insertarProveedor(oProveedor);
        }

        // PUT api/<controller>/5
        public bool Put([FromBody] Proveedor oProveedor)
        {
            return ProveedorData.ActualizarProveedor(oProveedor);
        }
        // DELETE api/<controller>/5
        public bool Delete(string id)
        {
            return ProveedorData.eliminarProveedor(id);
        }
    }
}