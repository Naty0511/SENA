using Facturacion_Berthoonline.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace Facturacion_Berthoonline.Data
{
    public class FacturaData
    {
        public static bool insertarFactura(Factura oFactura)
        {
            ConexionBD objEst = new ConexionBD();
            string sentencia;
            sentencia = "EXECUTE sp_insertar_factura '" + oFactura.numeroFactura + "','" + oFactura.idCliente + "','" +
oFactura.numeroPago + "','" + oFactura.IdVendedor + "','" + oFactura.fechaFactura + "','" + oFactura.fechaPedido + "','" + oFactura.numeroPedido + "'";

            if (!objEst.EjecutarSentencia(sentencia, false))

            {
                objEst = null;
                return false;
            }
            else
            {
                objEst = null;
                return true;
            }
        }

        public static List<Factura> Listar()
        {
            List<Factura> oListaFactura = new List<Factura>();
            ConexionBD objEst = new ConexionBD();
            string sentencia = "EXECUTE sp_listar_factura";

            try
            {
                if (objEst.Consultar(sentencia, false))
                {
                    SqlDataReader dr = objEst.Reader;
                    while (dr.Read())
                    {
                        oListaFactura.Add(new Factura()
                        {
                            numeroFactura = dr["numeroFactura"].ToString(),
                            idCliente = Convert.ToInt32(dr["idCliente"]),
                            numeroPago = dr["numeroPago"].ToString(),
                            IdVendedor = Convert.ToInt32(dr["IdVendedor"]),
                            fechaFactura = Convert.ToDateTime(dr["fechaFactura"]), 
                            fechaPedido = Convert.ToDateTime(dr["fechaPedido"]), 
                            numeroPedido = dr["numeroPedido"].ToString()
                        });
                    }
                    dr.Close(); // Cerrar el DataReader
                }
            }
            catch (Exception ex)
            {
                // Manejar la excepción (registrarla, volver a lanzarla, etc.)
                Console.WriteLine("Ocurrió un error: " + ex.Message);
            }
            finally
            {
                // Asegurarse de cerrar la conexión
                objEst.CerrarConexion();
            }

            return oListaFactura;
        }

    }
}