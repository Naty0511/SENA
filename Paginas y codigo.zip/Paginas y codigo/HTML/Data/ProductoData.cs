using Facturacion_Berthoonline.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace Facturacion_Berthoonline.Data
{
    public class ProductoData
    {
        public static bool insertarProducto(Producto oproducto)
        {
            ConexionBD objEst = new ConexionBD();
            string sentencia;
            sentencia = "EXECUTE sp_insertar_producto '" + oproducto.idProducto + "','" + oproducto.idCategoria + "','" +
oproducto.idProveedor + "','" + oproducto.nombreProducto + "','" + oproducto.descripcion + "','" + oproducto.existencias + "','" + oproducto.precioUnitario + "'";

            if (!objEst.EjecutarSentencia(sentencia, false))

            {
                objEst = null;
                return false;
            }
            else
            {
                objEst = null;
                return true;
            }
        }

        public static bool actualizarProducto(Producto oproducto)
        {
            ConexionBD objEst = new ConexionBD();
            string sentencia;
            sentencia = "EXECUTE sp_actualizar_producto '" + oproducto.idProducto + "','" + oproducto.idCategoria + "','" +
oproducto.idProveedor + "','" + oproducto.nombreProducto + "','" + oproducto.descripcion + "','" + oproducto.existencias + "','" + oproducto.precioUnitario + "'";

            if (!objEst.EjecutarSentencia(sentencia, false))

            {
                objEst = null;
                return false;
            }
            else
            {
                objEst = null;
                return true;
            }
        }


        public static bool eliminarProducto(string id)
        {
            ConexionBD objEst = new ConexionBD();
            string sentencia;
            sentencia = "EXECUTE sp_eliminarr_producto '" + id + "'";

            if (!objEst.EjecutarSentencia(sentencia, false))

            {
                objEst = null;
                return false;
            }
            else
            {
                objEst = null;
                return true;
            }
        }

        public static List<Producto> Listar()
        {
            List<Producto> oListaProducto = new List<Producto>();
            ConexionBD objEst = new ConexionBD();
            string sentencia = "EXECUTE sp_listar_producto";

            try
            {
                if (objEst.Consultar(sentencia, false))
                {
                    SqlDataReader dr = objEst.Reader;
                    while (dr.Read())
                    {
                        oListaProducto.Add(new Producto()
                        {
                            idProducto = Convert.ToInt32(dr["idProducto"]),
                            idCategoria = Convert.ToInt32(dr["idCategoria"]),
                            idProveedor = Convert.ToInt32(dr["idProveedor"]),
                            nombreProducto = dr["nombreProducto"].ToString(),
                            descripcion = dr["descripcion"].ToString(),
                            existencias = Convert.ToInt32(dr["existencias"]), 
                            precioUnitario = Convert.ToDecimal(dr["precioUnitario"]) 
                        });
                    }
                    dr.Close(); // Cerrar el DataReader
                }
            }
            catch (Exception ex)
            {
                // Manejar la excepción (registrarla, volver a lanzarla, etc.)
                Console.WriteLine("Ocurrió un error: " + ex.Message);
            }
            finally
            {
                // Asegurarse de cerrar la conexión
                objEst.CerrarConexion();
            }

            return oListaProducto;
        }

    }
}