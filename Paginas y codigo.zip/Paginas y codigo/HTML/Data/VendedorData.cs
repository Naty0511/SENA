using Facturacion_Berthoonline.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace Facturacion_Berthoonline.Data
{
    public class VendedorData
    {

        public static bool insertarVendedor (Vendedor oVendedor)
        {
            ConexionBD objEst = new ConexionBD();
            string sentencia;
            sentencia = "EXECUTE sp_insertar_cliente '" + oVendedor.idVendedor + "','" + oVendedor.cedula + "','" +
oVendedor.nombreVendedor + "','" + oVendedor.apellidoVendedor + "','" + oVendedor.direccion + "','" + oVendedor.telefono + "','" + oVendedor.email + "'";

            if (!objEst.EjecutarSentencia(sentencia, false))

            {
                objEst = null;
                return false;
            }
            else
            {
                objEst = null;
                return true;
            }
        }

        public static bool ActualizarVendedor(Vendedor oVendedor)
        {
            ConexionBD objEst = new ConexionBD();
            string sentencia;
            sentencia = "EXECUTE sp_actualizar_cliente '" + oVendedor.idVendedor + "','" + oVendedor.cedula + "','" +
oVendedor.nombreVendedor + "','" + oVendedor.apellidoVendedor + "','" + oVendedor.direccion + "','" + oVendedor.telefono + "','" + oVendedor.email + "'";

            if (!objEst.EjecutarSentencia(sentencia, false))

            {
                objEst = null;
                return false;
            }
            else
            {
                objEst = null;
                return true;
            }
        }

        public static bool eliminarVendedor(string id)
        {
            ConexionBD objEst = new ConexionBD();
            string sentencia;
            sentencia = "EXECUTE sp_eliminarr_vendedor '" + id + "'";

            if (!objEst.EjecutarSentencia(sentencia, false))

            {
                objEst = null;
                return false;
            }
            else
            {
                objEst = null;
                return true;
            }
        }

        public static List<Vendedor> Listar()
        {
            List<Vendedor> oListaVendedor = new List<Vendedor>();
            ConexionBD objEst = new ConexionBD();
            string sentencia;
            sentencia = "EXECUTE sp_listar_vendedor";
            if (objEst.Consultar(sentencia, false))
            {
                SqlDataReader dr = objEst.Reader;
                while (dr.Read())
                {
                    oListaVendedor.Add(new Vendedor()
                    {

                        idVendedor = Convert.ToInt32(dr["idVendedor"]),
                        cedula = dr["cedula"].ToString(),
                        nombreVendedor = dr["nombreVendedor"].ToString(),
                        apellidoVendedor = dr["apellidoVendedor"].ToString(),
                        direccion = dr["direccion"].ToString(),
                        telefono = dr["telefono"].ToString(),
                        email = dr["email"].ToString()
                    });
                }
                return oListaVendedor;
            }
            else
            {
                return oListaVendedor;
            }
        }
    }

}