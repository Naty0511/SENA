using Facturacion_Berthoonline.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace Facturacion_Berthoonline.Data
{
    public class ProveedorData
    {
        public static bool insertarProveedor(Proveedor oProveedor)
        {
            ConexionBD objEst = new ConexionBD();
            string sentencia;
            sentencia = "EXECUTE sp_insertar_proveedor '" + oProveedor.idProveedor + "','" + oProveedor.cedula + "','" +
oProveedor.nombreProveedor + "','" + oProveedor.apellidoProveedor + "','" + oProveedor.direccion + "','" + oProveedor.telefono + "','" + oProveedor.email + "'";

            if (!objEst.EjecutarSentencia(sentencia, false))

            {
                objEst = null;
                return false;
            }
            else
            {
                objEst = null;
                return true;
            }
        }

        public static bool ActualizarProveedor(Proveedor oProveedor)
        {
            ConexionBD objEst = new ConexionBD();
            string sentencia;
            sentencia = "EXECUTE sp_actualizar_cliente '" + oProveedor.idProveedor + "','" + oProveedor.cedula + "','" +
oProveedor.nombreProveedor + "','" + oProveedor.apellidoProveedor + "','" + oProveedor.direccion + "','" + oProveedor.telefono + "','" + oProveedor.email + "'";

            if (!objEst.EjecutarSentencia(sentencia, false))

            {
                objEst = null;
                return false;
            }
            else
            {
                objEst = null;
                return true;
            }
        }

        public static bool eliminarProveedor(string id)
        {
            ConexionBD objEst = new ConexionBD();
            string sentencia;
            sentencia = "EXECUTE sp_eliminarr_proveedor '" + id + "'";

            if (!objEst.EjecutarSentencia(sentencia, false))

            {
                objEst = null;
                return false;
            }
            else
            {
                objEst = null;
                return true;
            }
        }

        public static List<Proveedor> Listar()
        {
            List<Proveedor> oListaProveedor = new List<Proveedor>();
            ConexionBD objEst = new ConexionBD();
            string sentencia;
            sentencia = "EXECUTE sp_listar_proveedor";
            if (objEst.Consultar(sentencia, false))
            {
                SqlDataReader dr = objEst.Reader;
                while (dr.Read())
                {
                    oListaProveedor.Add(new Proveedor()
                    {

                        idProveedor = Convert.ToInt32(dr["idProveedor"]),
                        cedula = dr["cedula"].ToString(),
                        nombreProveedor = dr["nombreProveedor"].ToString(),
                        apellidoProveedor = dr["apellidoProveedor"].ToString(),
                        direccion = dr["direccion"].ToString(),
                        telefono = dr["telefono"].ToString(),
                        email = dr["email"].ToString()
                    });
                }
                return oListaProveedor;
            }
            else
            {
                return oListaProveedor;
            }
        }
    }
}
