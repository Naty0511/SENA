using Facturacion_Berthoonline.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace Facturacion_Berthoonline.Data
{
    public class ClienteData
    {
        public static bool insertarCliente(Cliente oCliente)
        {
            ConexionBD objEst = new ConexionBD();
            string sentencia;
            sentencia = "EXECUTE sp_insertar_cliente '" + oCliente.idCliente + "','" + oCliente.cedula + "','" +
oCliente.nombreCliente + "','" + oCliente.apellidoCliente + "','" + oCliente.direccion + "','" + oCliente.telefono + "','" + oCliente.email + "'";

            if (!objEst.EjecutarSentencia(sentencia, false))

            {
                objEst = null;
                return false;
            }
            else
            {
                objEst = null;
                return true;
            }
        }

        public static bool ActualizarCliente(Cliente oCliente)
        {
            ConexionBD objEst = new ConexionBD();
            string sentencia;
            sentencia = "EXECUTE sp_actualizar_cliente '" + oCliente.idCliente + "','" + oCliente.cedula + "','" +
oCliente.nombreCliente + "','" + oCliente.apellidoCliente + "','" + oCliente.direccion + "','" + oCliente.telefono + "','" + oCliente.email + "'";

            if (!objEst.EjecutarSentencia(sentencia, false))

            {
                objEst = null;
                return false;
            }
            else
            {
                objEst = null;
                return true;
            }
        }

        public static bool eliminarCliente(string id)
        {
            ConexionBD objEst = new ConexionBD();
            string sentencia;
            sentencia = "EXECUTE sp_eliminarr_cliente '" + id + "'";

            if (!objEst.EjecutarSentencia(sentencia, false))       

            {
                objEst = null;
                return false;
            }
            else
            {
                objEst = null;
                return true;
            }
        }

        public static List<Cliente> Listar()
        {
            List<Cliente> oListaCliente = new List<Cliente>();
            ConexionBD objEst = new ConexionBD();
            string sentencia;
            sentencia = "EXECUTE sp_listar_cliente";
            if (objEst.Consultar(sentencia, false))
            {
                SqlDataReader dr = objEst.Reader;
                while (dr.Read())
                {
                    oListaCliente.Add(new Cliente()
                    {

                        idCliente = Convert.ToInt32(dr["idCliente"]),
                        cedula = dr["cedula"].ToString(),
                        nombreCliente = dr["nombreCliente"].ToString(),
                        apellidoCliente = dr["apellidoCliente"].ToString(),
                        direccion = dr["direccion"].ToString(),
                        telefono = dr["telefono"].ToString(),
                        email = dr["email"].ToString()
                    });
                }
                return oListaCliente;
            }
            else
            {
                return oListaCliente;
            }
        }
    }

}