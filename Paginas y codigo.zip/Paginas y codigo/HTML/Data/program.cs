class Program
{
    static void Main(string[] args)
    {
        ConexionBD conexion = new ConexionBD(); // Crea una instancia de la clase de conexión

        if (conexion.ProbarConexion())
        {
            Console.WriteLine("Conexión exitosa a la base de datos.");
        }
        else
        {
            Console.WriteLine("No se pudo conectar a la base de datos.");
        }
    }
}
